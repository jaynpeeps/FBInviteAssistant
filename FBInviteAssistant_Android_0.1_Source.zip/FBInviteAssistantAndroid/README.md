# FB Invite Assistant — Android screen-off test build

This is a **prototype/test build**, not the finished unattended app.

## What this build is designed to prove

1. Facebook can stay logged in inside the app's WebView.
2. The invite engine can cycle reaction categories automatically:
   **All → Like → Love/Heart → Care → Haha/Laugh → Wow → Sad → Angry**.
3. The engine can scroll each reaction list and click only controls whose visible/accessible label is exactly **Invite**.
4. A foreground service + partial CPU wake lock can keep emitting automation ticks while the phone's display is off.
5. The run stops when:
   - the user stops it,
   - the configured max invite count is reached,
   - the phone is unplugged when "Require charging" is enabled,
   - a common Facebook restriction / verification message is detected, or
   - all reaction categories reach a stable bottom.

## First test procedure

Keep the default **Max = 25** for the first locked-screen test.

1. Install the APK.
2. Allow notifications when Android asks. The foreground notification is how Android knows the run is intentionally active.
3. Open the app.
4. Log into Facebook in the embedded browser.
5. Open one Facebook Page post or Reel.
6. Open **People who reacted**.
7. Leave the list open. Any reaction tab is fine; the engine attempts to cycle all available categories itself.
8. Plug the phone into power.
9. Leave **Require charging during run** checked.
10. Leave **Delay = 1** and **Max = 25**.
11. Tap **START TEST**.
12. Wait until at least one invite is sent while the display is on.
13. Lock the phone / turn the display off for roughly 5 minutes.
14. Unlock the phone and reopen the app or inspect the persistent notification.
15. Record:
    - total invites sent,
    - current reaction category,
    - whether the count increased while the display was off,
    - whether Facebook showed any verification/restriction screen.

If the count increased while locked, the hardest technical assumption has passed.

## Important limitations of 0.1

- You manually navigate to **one post's reactor list** before starting.
- It does **not yet discover recent posts/Reels on its own**.
- It does **not yet automatically start when charging**.
- The foreground worker is capped at 2 hours for this test build.
- Facebook can change its mobile-web DOM at any time.
- The app does not bypass Facebook limits, CAPTCHA, login verification, or restrictions.

## Planned next milestone after screen-off test passes

- Save/checkpoint per post + per reaction category.
- Discover recent Page posts/Reels automatically.
- Run in short charging-only background chunks.
- Resume from checkpoints after unplug/replug or process interruption.
- Charging-triggered scheduling without requiring a fixed 2:00 AM time.

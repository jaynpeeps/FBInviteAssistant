(function () {
  if (window.FBIA && window.FBIA.version === "0.1") return "already_loaded";

  const reactionDefs = [
    {key:"all", names:["all"]},
    {key:"like", names:["like"]},
    {key:"love", names:["love","heart"]},
    {key:"care", names:["care"]},
    {key:"haha", names:["haha","laugh"]},
    {key:"wow", names:["wow"]},
    {key:"sad", names:["sad"]},
    {key:"angry", names:["angry"]}
  ];

  const stopPhrases = [
    "temporarily blocked",
    "try again later",
    "we limit how often",
    "you can't use this feature right now",
    "you can’t use this feature right now",
    "couldn't send invite",
    "couldn’t send invite",
    "we restrict certain activity",
    "captcha",
    "confirm your identity"
  ];

  const st = {
    running:false,
    sent:0,
    maxInvites:25,
    categoryIndex:0,
    currentCategory:"all",
    highWater:0,
    bottomSince:0,
    lastHeight:0,
    lastFingerprint:"",
    tabWaitUntil:0,
    doneCategories:{},
    tickBusy:false
  };

  function n(v) { return (v || "").replace(/\s+/g, " ").trim(); }
  function low(v) { return n(v).toLowerCase(); }
  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.display !== "none" &&
           s.visibility !== "hidden" && s.opacity !== "0";
  }
  function labels(el) {
    const vals = [
      n(el.innerText || el.textContent),
      n(el.getAttribute && el.getAttribute("aria-label")),
      n(el.getAttribute && el.getAttribute("title"))
    ];
    try {
      el.querySelectorAll("img").forEach(img => {
        vals.push(n(img.getAttribute("alt")));
        vals.push(n(img.getAttribute("aria-label")));
      });
    } catch (_) {}
    return vals.filter(Boolean);
  }

  function report(status, extra={}) {
    const payload = Object.assign({
      sent:st.sent,
      category:st.currentCategory,
      status,
      done:false,
      warning:false
    }, extra);
    try { AndroidBridge.report(JSON.stringify(payload)); } catch (_) {}
  }

  function bodyWarning() {
    const t = low(document.body && document.body.innerText);
    return stopPhrases.find(p => t.includes(p)) || "";
  }

  function controls() {
    return Array.from(document.querySelectorAll('button,[role="button"],[role="tab"],a'));
  }

  function isInvite(el) {
    if (!visible(el)) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    return labels(el).some(x => low(x) === "invite");
  }

  function allInvites() {
    return controls().filter(isInvite);
  }

  function chooseScroller() {
    const invites = allInvites();
    const candidates = Array.from(document.querySelectorAll("div,section,main"))
      .filter(el => {
        if (!visible(el)) return false;
        if (el.scrollHeight <= el.clientHeight + 40) return false;
        const o = getComputedStyle(el).overflowY;
        return o === "auto" || o === "scroll";
      })
      .map(el => {
        const contained = invites.filter(b => el.contains(b)).length;
        return {el, score: contained * 100000 + (el.scrollHeight - el.clientHeight)};
      })
      .sort((a,b) => b.score - a.score);

    return candidates.length ? candidates[0].el : (document.scrollingElement || document.documentElement);
  }

  function scrollState(scroller) {
    const d = document.scrollingElement || document.documentElement;
    const doc = scroller === d || scroller === document.documentElement || scroller === document.body;
    if (doc) {
      const top = window.scrollY || d.scrollTop || 0;
      const viewport = window.innerHeight;
      const height = Math.max(d.scrollHeight, document.body ? document.body.scrollHeight : 0);
      return {top, viewport, height, max:Math.max(0,height-viewport), doc:true};
    }
    return {
      top:scroller.scrollTop,
      viewport:scroller.clientHeight,
      height:scroller.scrollHeight,
      max:Math.max(0,scroller.scrollHeight-scroller.clientHeight),
      doc:false
    };
  }

  function setTop(scroller, y) {
    const d = document.scrollingElement || document.documentElement;
    if (scroller === d || scroller === document.documentElement || scroller === document.body) {
      window.scrollTo(0, Math.max(0,y));
    } else scroller.scrollTop = Math.max(0,y);
  }

  function inScrollerView(el, scroller) {
    if (!visible(el)) return false;
    const r = el.getBoundingClientRect();
    const d = document.scrollingElement || document.documentElement;
    if (scroller === d || scroller === document.documentElement || scroller === document.body) {
      return r.bottom >= -40 && r.top <= window.innerHeight + 40;
    }
    const s = scroller.getBoundingClientRect();
    return r.bottom >= s.top - 40 && r.top <= s.bottom + 40;
  }

  function visibleInvites(scroller) {
    return allInvites().filter(x => inScrollerView(x, scroller))
      .sort((a,b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);
  }

  function fingerprint(scroller) {
    const d = document.scrollingElement || document.documentElement;
    let top = 0, bottom = innerHeight;
    if (!(scroller === d || scroller === document.documentElement || scroller === document.body)) {
      const r = scroller.getBoundingClientRect();
      top = r.top; bottom = r.bottom;
    }
    return Array.from(document.querySelectorAll("a,span,div"))
      .filter(el => {
        if (!visible(el)) return false;
        const r = el.getBoundingClientRect();
        if (r.bottom < top || r.top > bottom) return false;
        const t = n(el.innerText || el.textContent);
        return t && t.length < 90;
      })
      .map(el => n(el.innerText || el.textContent))
      .slice(-30).join("|").slice(-1600);
  }

  function tabFor(def) {
    const els = controls().filter(visible);
    for (const el of els) {
      const ls = labels(el).map(low);
      for (const candidate of def.names) {
        if (ls.some(x => x === candidate || x.startsWith(candidate + " ") ||
                         x.includes(candidate + " reactions") ||
                         x.includes(candidate + " reaction"))) {
          return el;
        }
      }
    }
    return null;
  }

  function switchToCategory(index) {
    while (index < reactionDefs.length) {
      const def = reactionDefs[index];
      const tab = tabFor(def);
      if (tab) {
        st.categoryIndex = index;
        st.currentCategory = def.key;
        st.highWater = 0;
        st.bottomSince = 0;
        st.lastHeight = 0;
        st.lastFingerprint = "";
        st.tabWaitUntil = Date.now() + 1600;
        tab.click();
        report("Switched reaction tab; waiting for Facebook to render.");
        return true;
      }
      st.doneCategories[def.key] = "not_present";
      index++;
    }
    finish("All available reaction categories completed.");
    return false;
  }

  function finish(message) {
    st.running = false;
    report(message, {done:true});
  }

  function start(config) {
    st.running = true;
    st.sent = 0;
    st.maxInvites = Math.max(0, Number(config && config.maxInvites) || 0);
    st.categoryIndex = 0;
    st.currentCategory = "all";
    st.highWater = 0;
    st.bottomSince = 0;
    st.lastHeight = 0;
    st.lastFingerprint = "";
    st.doneCategories = {};
    st.tickBusy = false;

    // Start with All when it exists, otherwise first available category.
    if (!switchToCategory(0)) return;
    report("Started. Screen may be turned off.");
  }

  function stop(reason) {
    st.running = false;
    report(reason || "Stopped.", {done:true});
  }

  function step() {
    if (!st.running || st.tickBusy) return "idle";
    st.tickBusy = true;
    try {
      const warning = bodyWarning();
      if (warning) {
        st.running = false;
        report("Facebook warning detected: " + warning, {warning:true});
        return "warning";
      }

      if (Date.now() < st.tabWaitUntil) {
        report("Waiting for reaction tab to finish loading.");
        return "wait_tab";
      }

      const scroller = chooseScroller();
      let pos = scrollState(scroller);

      // Recover if Facebook re-rendered and jumped us upward.
      if (pos.top < st.highWater - Math.max(180, pos.viewport * 0.25)) {
        setTop(scroller, st.highWater);
        report("Recovered Facebook scroll reset.");
        return "recover";
      }

      const invites = visibleInvites(scroller);
      if (invites.length) {
        const button = invites[0];
        const before = pos.top;
        st.highWater = Math.max(st.highWater, before);
        button.click();
        st.sent++;
        st.bottomSince = 0;
        report("Invite sent.");

        if (st.maxInvites > 0 && st.sent >= st.maxInvites) {
          finish("Reached the test maximum of " + st.maxInvites + " invites.");
          return "max";
        }
        return "clicked";
      }

      // No Invite button on this screen. Move forward.
      pos = scrollState(scroller);
      const stepSize = Math.max(320, Math.floor(pos.viewport * 0.82));
      const target = Math.min(pos.max, Math.max(pos.top, st.highWater) + stepSize);

      if (target > pos.top + 4) {
        setTop(scroller, target);
        st.highWater = Math.max(st.highWater, target);
        st.bottomSince = 0;
        report("Scanning forward.");
        return "scroll";
      }

      // At current bottom: wait for Facebook lazy-loading and require a stable
      // bottom before considering this reaction category complete.
      setTop(scroller, pos.max);
      st.highWater = Math.max(st.highWater, pos.max);
      const fp = fingerprint(scroller);
      const changed = pos.height !== st.lastHeight || fp !== st.lastFingerprint;

      if (changed) {
        st.lastHeight = pos.height;
        st.lastFingerprint = fp;
        st.bottomSince = Date.now();
        report("At current bottom; waiting for more people to load.");
        return "bottom_changed";
      }

      if (!st.bottomSince) st.bottomSince = Date.now();

      if (Date.now() - st.bottomSince >= 12000) {
        st.doneCategories[st.currentCategory] = "complete";
        report("Reaction category complete; moving to the next one.");
        switchToCategory(st.categoryIndex + 1);
        return "next_tab";
      }

      report("Confirming bottom of " + st.currentCategory + ".");
      return "bottom_wait";
    } catch (e) {
      st.running = false;
      report("Stopped because Facebook changed unexpectedly: " + String(e), {warning:true});
      return "error";
    } finally {
      st.tickBusy = false;
    }
  }

  window.FBIA = {version:"0.1", start, stop, step, state:st};
  return "loaded";
})();

package com.cowboysmemehq.inviteassistant;

import android.app.*;
import android.content.*;
import android.os.*;

/**
 * Keeps the process and CPU alive while the screen is off.
 * It does not bypass Facebook controls. It simply emits one automation tick
 * per configured interval to the Activity's already-loaded WebView.
 */
public class InviteRunService extends Service {
    public static final String ACTION_TICK = "com.cowboysmemehq.inviteassistant.TICK";
    public static final String ACTION_STOP = "com.cowboysmemehq.inviteassistant.STOP";
    private static final String CHANNEL = "invite_run";
    private static final int NOTIFICATION_ID = 4107;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private long delayMs = 1000L;
    private boolean requireCharging = true;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (requireCharging && !PowerUtil.isCharging(InviteRunService.this)) {
                stopWithReason("Paused because the phone was unplugged.");
                return;
            }
            Intent i = new Intent(ACTION_TICK);
            i.setPackage(getPackageName());
            sendBroadcast(i);
            updateNotification();
            handler.postDelayed(this, Math.max(1000L, delayMs));
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopWithReason("Stopped.");
            return START_NOT_STICKY;
        }

        if (intent != null) {
            delayMs = Math.max(1000L, intent.getLongExtra("delayMs", 1000L));
            requireCharging = intent.getBooleanExtra("requireCharging", true);
        }

        if (requireCharging && !PowerUtil.isCharging(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification());

        if (wakeLock == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FBInviteAssistant:Run");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire(2 * 60 * 60 * 1000L); // safety cap: 2 hours for test build
        }

        handler.removeCallbacks(ticker);
        handler.post(ticker);
        return START_NOT_STICKY;
    }

    private void stopWithReason(String reason) {
        getSharedPreferences("state", MODE_PRIVATE).edit().putString("serviceReason", reason).apply();
        handler.removeCallbacks(ticker);
        releaseWakeLock();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void updateNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private Notification buildNotification() {
        android.content.SharedPreferences p = getSharedPreferences("state", MODE_PRIVATE);
        int sent = p.getInt("sent", 0);
        String category = p.getString("category", "starting");
        String status = p.getString("status", "Running");

        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, InviteRunService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 11, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("FB Invite Assistant running")
                .setContentText(sent + " sent • " + category + " • " + status)
                .setContentIntent(pi)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPi).build())
                .build();
    }

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel c = new NotificationChannel(
                CHANNEL, "Invite runs", NotificationManager.IMPORTANCE_LOW);
        c.setDescription("Shows progress while an invite test is running.");
        nm.createNotificationChannel(c);
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {}
        wakeLock = null;
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(ticker);
        releaseWakeLock();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) {
        return null;
    }
}

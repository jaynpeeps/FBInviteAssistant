package com.cowboysmemehq.inviteassistant;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView web;
    private TextView status;
    private EditText delay;
    private EditText maxInvites;
    private CheckBox requireCharging;
    private Button startButton;
    private Button stopButton;
    private String engineJs = "";
    private boolean engineInjected = false;

    private final BroadcastReceiver tickReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (InviteRunService.ACTION_TICK.equals(intent.getAction())) {
                if (web != null) {
                    web.evaluateJavascript(
                        "window.FBIA ? window.FBIA.step() : 'engine_missing';",
                        value -> {
                            if ("\"engine_missing\"".equals(value)) injectEngine();
                        });
                }
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestNotificationsIfNeeded();
        engineJs = readAsset("invite_engine.js");
        setContentView(buildUi());

        IntentFilter tickFilter = new IntentFilter(InviteRunService.ACTION_TICK);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(tickReceiver, tickFilter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(tickReceiver, tickFilter);
        }

        configureWebView();

        if (savedInstanceState == null) {
            web.loadUrl("https://www.facebook.com/");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    private View buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(Color.rgb(247,248,250));

        TextView title = new TextView(this);
        title.setText("FB Invite Assistant • Screen-off Test 0.1");
        title.setTextSize(17);
        title.setTextColor(Color.BLACK);
        title.setTypeface(null, 1);
        bar.addView(title);

        TextView hint = new TextView(this);
        hint.setText("1) Log into Facebook below.  2) Open ONE post/reel.  3) Open People who reacted.  4) Leave it on any reaction tab.  5) Start test, then turn the screen off.");
        hint.setTextSize(12);
        hint.setTextColor(Color.DKGRAY);
        hint.setPadding(0, dp(4), 0, dp(7));
        bar.addView(hint);

        LinearLayout settings = new LinearLayout(this);
        settings.setOrientation(LinearLayout.HORIZONTAL);

        delay = new EditText(this);
        delay.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        delay.setText("1");
        delay.setHint("Delay sec");
        settings.addView(delay, new LinearLayout.LayoutParams(0, dp(46), 1));

        maxInvites = new EditText(this);
        maxInvites.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        maxInvites.setText("25");
        maxInvites.setHint("Max (0=all)");
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, dp(46), 1);
        mp.setMarginStart(dp(6));
        settings.addView(maxInvites, mp);

        bar.addView(settings);

        requireCharging = new CheckBox(this);
        requireCharging.setText("Require charging during run");
        requireCharging.setChecked(true);
        bar.addView(requireCharging);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        startButton = new Button(this);
        startButton.setText("START TEST");
        startButton.setOnClickListener(v -> startRun());
        buttons.addView(startButton, new LinearLayout.LayoutParams(0, dp(48), 1));

        stopButton = new Button(this);
        stopButton.setText("STOP");
        stopButton.setOnClickListener(v -> stopRun());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, dp(48), 1);
        sp.setMarginStart(dp(6));
        buttons.addView(stopButton, sp);

        bar.addView(buttons);

        status = new TextView(this);
        status.setText("Ready. The first test defaults to 25 invites.");
        status.setTextSize(12);
        status.setTextColor(Color.rgb(45,55,65));
        status.setPadding(dp(4), dp(6), dp(4), dp(2));
        bar.addView(status);

        root.addView(bar);

        web = new WebView(this);
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString() + " FBInviteAssistant/0.1");

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new JsBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                engineInjected = false;
                injectEngine();
                status.setText("Facebook loaded. Navigate to a post's People who reacted list.");
            }
        });
        web.setWebChromeClient(new WebChromeClient());
    }

    private void injectEngine() {
        if (engineJs == null || engineJs.isEmpty() || web == null) return;
        web.evaluateJavascript(engineJs, value -> engineInjected = true);
    }

    private void startRun() {
        if (requireCharging.isChecked() && !PowerUtil.isCharging(this)) {
            Toast.makeText(this, "Plug the phone in first, or uncheck Require charging.", Toast.LENGTH_LONG).show();
            return;
        }

        int d = parseInt(delay.getText().toString(), 1);
        int max = parseInt(maxInvites.getText().toString(), 25);
        if (d < 1) d = 1;

        getSharedPreferences("state", MODE_PRIVATE).edit()
                .putInt("sent", 0)
                .putString("category", "starting")
                .putString("status", "Starting")
                .apply();

        final int delayFinal = d;
        final int maxFinal = max;

        injectEngine();
        web.evaluateJavascript(
            "window.FBIA && window.FBIA.start({delaySeconds:" + delayFinal +
            ",maxInvites:" + maxFinal + ",cycleTabs:true});",
            null
        );

        Intent service = new Intent(this, InviteRunService.class);
        service.putExtra("delayMs", delayFinal * 1000L);
        service.putExtra("requireCharging", requireCharging.isChecked());
        startForegroundService(service);

        status.setText("RUNNING. You can now turn the screen off. Keep the phone plugged in if charging is required.");
    }

    private void stopRun() {
        if (web != null) {
            web.evaluateJavascript("window.FBIA && window.FBIA.stop('Stopped manually');", null);
        }
        Intent stop = new Intent(this, InviteRunService.class);
        stop.setAction(InviteRunService.ACTION_STOP);
        startService(stop);
        status.setText("Stopped.");
    }

    private int parseInt(String s, int fallback) {
        try { return Integer.parseInt(s.trim()); } catch (Throwable t) { return fallback; }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        } catch (Throwable t) {
            return "";
        }
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 220);
        }
    }

    public class JsBridge {
        @JavascriptInterface public void report(String json) {
            runOnUiThread(() -> {
                try {
                    JSONObject o = new JSONObject(json);
                    int sent = o.optInt("sent", 0);
                    String category = o.optString("category", "");
                    String text = o.optString("status", "");
                    boolean done = o.optBoolean("done", false);
                    boolean warning = o.optBoolean("warning", false);

                    getSharedPreferences("state", MODE_PRIVATE).edit()
                            .putInt("sent", sent)
                            .putString("category", category)
                            .putString("status", text)
                            .apply();

                    status.setText("Sent: " + sent + " • " + category + " • " + text);

                    if (done || warning) {
                        Intent stop = new Intent(MainActivity.this, InviteRunService.class);
                        stop.setAction(InviteRunService.ACTION_STOP);
                        startService(stop);
                    }
                } catch (Throwable ignored) {}
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onSaveInstanceState(android.os.Bundle outState) {
        if (web != null) web.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(tickReceiver); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
